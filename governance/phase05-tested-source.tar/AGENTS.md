# Development instructions

Read MASTER-CONTRACT.md and harness/state.json. This distribution has no authorized step or writable owner. Obtain explicit human authorization, verify prerequisites and scope, run real checks and retain evidence, and stop at the authorized boundary. See harness/README.md.
