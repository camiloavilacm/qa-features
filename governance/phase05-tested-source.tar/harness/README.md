# Development harness

This controller governs coding agents. It is never imported by pytest-bdd/Cypress or run in deterministic QA CI. Active work is Phase 0.5 completion; Step 1 has already been requested but awaits its other prerequisites. No product repositories exist. See MASTER-CONTRACT.md for architectural authority.

## Bootstrap and verify

Use Python 3.11+ (tested on 3.14.4). From the workspace root:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r harness/requirements.txt
.venv/bin/python harness/scripts/sync_skills.py --check
.venv/bin/python harness/scripts/preflight.py --step 0.5 --provider codex --owner phase05-builder
.venv/bin/python harness/scripts/validate_adapters.py
.venv/bin/python -m unittest discover -s harness/evals -p 'test_*.py' -v
```

JSON-compatible YAML configuration deliberately uses the YAML JSON subset. PyYAML parses it; schemas use JSON Schema 2020-12. Dependencies are isolated, pinned, and unrelated to future runner environments.

Before implementation retain an external protected filesystem baseline; `scope_guard.py --baseline <path> --capture` refuses overwrite. For this preparation run the retained baseline is harness/evidence/baseline.json plus the Phase 0 workspace manifest. Final auditing uses `scope_guard.py --baseline harness/evidence/baseline.json`. Baseline loss is a blocker, never permission to silently reset it.

## Evidence and gates

The operator provisions an external random recorder key of at least 32 bytes, mode 0600, and sets QA_EVIDENCE_KEY_FILE. This run stores its key in the sibling qa-workspace-control directory; never commit it or print its contents. Evidence records execution, source fingerprint, logs and HMAC. Key holders can sign evidence: this detects edited/fabricated records without the key, not malicious actions by the trusted recorder itself. Independently protect the baseline, ledger and recorder key with OS permissions and human review. Same-user agents cannot be sandboxed by their own editable scripts alone.

```sh
.venv/bin/python harness/scripts/verify_step.py run --check adapters
.venv/bin/python harness/scripts/verify_step.py run --check evals
.venv/bin/python harness/scripts/verify_step.py run --check codex-native
.venv/bin/python harness/scripts/verify_step.py run --check claude-artifacts
.venv/bin/python harness/scripts/verify_step.py run --check antigravity-native
.venv/bin/python harness/scripts/verify_step.py run --check native-cycle
.venv/bin/python harness/scripts/verify_step.py validate
.venv/bin/python harness/scripts/verify_step.py gate
```

Native parser/discovery probes return PASS only for their limited measured scope. A separate required native-cycle check follows the approved provider profile through real ownership release/claim operations. The current user-approved claude-artifacts-only profile runs Antigravity → Codex → Antigravity and requires static Claude artifact validation; Claude live checks remain NOT RUN and do not block the current gate. The all-live profile retains the original four-session cycle. Credit/auth/timeouts or inactive config produce NOT RUN; missing denial/lifecycle evidence or changed files produce FAIL. No command marks a phase complete or authorizes another phase. Live probes (`live_probe.py <provider>`) run sequentially in temporary fixtures; their bounded session checks are development-only model calls and cannot attest the entire acceptance suite. Do not run them as QA CI. Record absent authentication, unsupported tools, timeouts and missing native events explicitly.

## Ownership and approvals

Read-only inspection is permitted without claiming writable ownership. To switch writers, use `ownership.py release --provider <old> --owner <id> --handoff harness/evidence/handoff.json`, then `ownership.py claim --provider <new> --owner <id> --handoff harness/evidence/handoff.json`. Receiving owner inspects the handoff and Git state, then runs preflight. The transfer is serialized with a file lock and refuses unreleased ownership or changed handoff state. No parallel writers.

For a product step, a human must maintain an external QA_AUTHORIZATION_FILE with step, source=human, reference, and approved_feature_ref, matching the persisted authorization. The controller does not create it. State edits alone cannot grant product access. The external file and state are administrative inputs, not an identity/authentication service; protect them externally. Feature/tooling refs must resolve to recorded immutable commits when set. Feature tagging remains human controlled. Missing Phase 0 prerequisites and prior contracts block Step 1.

## Provider controls and gaps

Antigravity uses .agents/hooks.json with named hook groups, native camelCase payloads and decision=deny; PostToolUse returns empty JSON, so audit findings are persisted for external review. Rules use trigger=always_on. A stdlib-only launcher reads workspacePaths from the native payload and invokes the absolute project interpreter/script path; it does not assume the hook working directory. Live verification must confirm this for each surface.

Claude uses .claude/settings.json, snake_case tool fields and hookSpecificOutput.permissionDecision. CLAUDE.md contains only @AGENTS.md; documented import handling avoids duplicate loading. A user's managed-only instructions or disabled hooks can bypass project customizations; live verification remains mandatory. Stop hooks report blockers without creating infinite continuation loops.

Codex uses project sandbox/approval defaults and execpolicy rules. No custom Codex lifecycle hooks are configured. Trusted project activation is required; scope enforcement relies on OS sandbox and explicit preflight/audit, not command rules as a filesystem sandbox. Native probes use a temporary command-line trust setting, never edit personal trust configuration or select a model.

File-tool actions are checked before writes where supported. Unknown tools are denied. Claude shell effects require scoped human permission; Antigravity shell calls are denied pending external scoped execution because headless ask semantics were not reliable in the live probe. Shell text is not treated as a safe filesystem proof. Final auditing checks tracked/untracked paths, empty directories, symlinks and Git references. Non-root .venv directories are included. .git internals, Python caches and the root isolated environment require provider permissions; they are excluded from content hashing. Evidence permits only report/log/JSON/lock artifacts and validates recorder records separately. Audit cannot detect transient writes that were reverted, changes outside inspected workspaces, or files hidden in excluded runtime directories; native sandboxing and independent review cover these gaps.

## Provenance and clean checkout

Before Step 1, source is this non-Git workspace. Export with package_governance.py --output <new-tar-path> to retain a reproducible source bundle and file hashes. Use --repository <authorized-repository-name> when generating a repository-local bundle; location metadata maps local paths to the central step policy and requires an independent Git root. It creates no repository itself. On Step 1 preserve the canonical source under qa-features governance separately from business contracts. Later authorized repositories receive generated native artifacts plus self-contained shared scripts/contracts and a provenance manifest. Do not depend on parent untracked files or cross-repository symlinks. Distribution initializes state with no authorization or writable owner; an operator supplies local authorization. Clean-room export tests run in disposable fixtures without creating actual product repositories. Native discovery from each real repository remains an acceptance check when it is created.

The native cycle uses a temporary Codex home and --trust only for its disposable fixture, with a temporary login-file link. It never saves trust or configuration in the personal Codex home, copies credentials into governance, or disables the read-only sandbox. Model responses alone cannot establish enforcement: actual tool-denial diagnostics/events and unchanged files are required. Legacy live_probe.py remains a partial diagnostic, not the completion check.

## Claude prepared without account access

The Claude files are retained and synchronized, not removed. See .claude/ACTIVATION.md. Current validation needs no Claude executable, account or credits. The profile exception is recorded in MASTER-CONTRACT.md and harness/approved-exceptions.json. Artifacts-only Claude cannot claim writable ownership. Never report it as live-validated. Older logs of unavailable Claude access are historical and no longer block the active profile.
