# Decisions and unresolved inputs

Approved: five independent repositories; one shared multi-harness controller with three native adapters; deterministic QA CI; one writable owner; explicit step and feature-approval boundaries. Source: user-supplied v2 architecture.

Preparation choices confirmed by user: documents/specifications only; separate sibling /Users/camiloavila/Documents/qa-workspace; original Git repository untouched. The workspace itself remains unversioned until authorized governance preservation in qa-features.

Missing prior inputs must not be invented: complete original SEED-1 text and AC tags; exact previously approved Conduit schema/error behavior; full locked technology/version/exclusion list; agreed baseline identity and protected route; selectors and result/campaign field definitions; GitHub organization/access and CI arrangement. The supplied frozen rules remain binding. These omissions block dependent specification/implementation, not this documentation pass.

Provider protocol facts, configuration syntax, instruction import behavior, skill discovery and hook blocking support require official documentation and installed-version/live checks during harness implementation. No compatibility claims are made here.

## Phase 0 authorization and findings

User subsequently authorized `phase 0`. This supersedes the documentation-only boundary for readiness checks, not for Phase 0.5 implementation. See phase-0-report.md and phase-0-evidence.json. Antigravity is now confirmed available via agy CLI and application metadata; the earlier PATH probe checked only antigravity. Hurl/hurlfmt remain unavailable. GitHub authentication/public access is confirmed, but target repository/CI permissions remain unspecified. No missing prior contract detail has been invented.

## Phase 0.5 authorization

The user explicitly requested `Move to Phase 0.5`, authorizing the shared controller, four skills, native adapters and preparation evaluations. Step 1 remains unauthorized. See harness/decisions.md for implementation choices and phase-05-report.md for limitations/evidence.
